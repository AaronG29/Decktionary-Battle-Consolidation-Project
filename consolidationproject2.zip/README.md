READ ME

Decktionary Battle is a two player game where each player gets 8 cards. Players will each take a turn choosing a card from their hand until there are none remaining. The game will go on for 8 rounds. The winner of each round is decided on the rank and the suit, you will want to play a high card that matches the former suit the the initial player chose. 

How to Play
Start the Game: The game starts by creating a shuffled deck and dealing cards to each player.
Player 1 selects a card from their hand to play.
Player 2 then selects a card from their hand to play.
The code will compare the cards the winner based on the highest value with the matching suit
The game continues for 8 rounds. After each round you will be shown the score in order to keep track.
After 8 rounds, the final scores are displayed, and the player with the higher score wins the game.